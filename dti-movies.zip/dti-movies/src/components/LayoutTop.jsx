import React from "react";
import './LayoutTop.css';

export default () =>
  <header className="layout-top">
    <div className="wrapper">
      <h1>Dti Movies</h1>
    </div>
  </header>